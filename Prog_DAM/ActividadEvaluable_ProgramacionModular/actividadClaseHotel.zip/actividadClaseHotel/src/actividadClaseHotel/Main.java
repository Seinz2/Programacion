package actividadClaseHotel;

import java.util.Scanner;

public class Main {
	static Scanner teclado = new Scanner (System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hotel hotel = new Hotel();

        hotel.nuevaHabitacion("S11", 1, "simple", 50.0, true);
        hotel.nuevaHabitacion("D232", 2, "doble", 80.0, false);
        hotel.nuevaHabitacion("M361", 3, "matrimonial", 100.0, true);
        hotel.nuevaHabitacion("E491", 4, "especial", 120.0, false);

        hotel.listarHabitaciones();
        System.out.println("\nHabitaciones disponibles:");
        hotel.listarHabitacionesDisponibles();

        System.out.print("\nIntroduce el identificador de la habitación para obtener su precio: ");
        String identificadorPrecio = teclado.next();
        double precio = hotel.obtenerPrecioPorIdentificador(identificadorPrecio);
        if (precio != -1) {
            System.out.println("El precio de la habitación " + identificadorPrecio + " es: " + precio);
        } else {
            System.out.println("No existe ninguna habitación con ese código.");
        }

        System.out.print("\nIntroduce el identificador de la habitación para hacer una reserva: ");
        String identificadorReserva = teclado.next();
        hotel.hacerReserva(identificadorReserva);

        System.out.println("\nHabitaciones reservadas:");
        hotel.listarHabitacionesReservadas();

	}

}
