package actividadClaseHotel;

public class Habitaciones {
    private String identificador;
    private int planta;
    private String tipo;
    private double precio;
    private boolean ocupado;
    private boolean tieneVistaExterior;

    
    public Habitaciones(String identificador, int planta, String tipo, double precio, boolean tieneVistaExterior) {
        this.identificador = identificador;
        this.planta = planta;
        this.tipo = tipo;
        this.precio = precio;
        this.ocupado = false;
        this.tieneVistaExterior = tieneVistaExterior;
    }


    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public int getPlanta() {
        return planta;
    }

    public void setPlanta(int planta) {
        this.planta = planta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean getOcupado() {
        return ocupado;
    }

    public void setOcupado(boolean ocupado) {
        this.ocupado = ocupado;
    }

    public boolean getTieneVistaExterior() {
        return tieneVistaExterior;
    }

    public void setTieneVistaExterior(boolean tieneVistaExterior) {
        this.tieneVistaExterior = tieneVistaExterior;
    }

    
    public String toString() {
        return "Habitacion [identificador=" + identificador + ", planta=" + planta + ", tipo=" + tipo + ", precio="
                + precio + ", ocupado=" + ocupado + ", tieneVistaExterior=" + tieneVistaExterior + "]";
    }
}
