package actividadClaseHotel;

public class Hotel {
    private Habitaciones[] habitaciones;

    
    public Hotel() {
        habitaciones = new Habitaciones[10];
    }

    /**
	 * busca la primera posicion libre e inserta una habitacion.
	 * 
	 * @param identificador : string
	 * @param planta: entero
	 * @param tipo : string
	 * @param precio : double
	 * @param tieneVistaExterior : boolean
	 * @return
	 */
    public void nuevaHabitacion(String identificador, int planta, String tipo, double precio, boolean tieneVistaExterior) {
        for (int i = 0; i < habitaciones.length; i++) {
            if (habitaciones[i] == null) {
                habitaciones[i] = new Habitaciones(identificador, planta, tipo, precio, tieneVistaExterior);
                System.out.println("Habitación creada: " + habitaciones[i]);
                return;
            }
        }
        System.out.println("No hay huecos libres para crear una nueva habitación.");
    }
    
    /**
	 * a partir de un identificador, busca la habitacion, si la encuentra y esta disponible la elimina.
	 * 
	 * @param identificador : string
	 * @return
	 */
    public void borrarHabitacion(String identificador) {
        for (int i = 0; i < habitaciones.length; i++) {
            if (habitaciones[i] != null && habitaciones[i].getIdentificador().equals(identificador)) {
                if (!habitaciones[i].getOcupado()) {
                    habitaciones[i] = null;
                    System.out.println("Habitación borrada: " + identificador);
                    return;
                } else {
                    System.out.println("No se puede borrar una habitación ocupada.");
                    return;
                }
            }
        }
        System.out.println("No existe ninguna habitación con ese código.");
    }

    public void listarHabitaciones() {
        for (Habitaciones habitacion : habitaciones) {
            if (habitacion != null) {
                System.out.println(habitacion);
            }
        }
    }

    public void listarHabitacionesDisponibles() {
        for (Habitaciones habitacion : habitaciones) {
            if (habitacion != null && !habitacion.getOcupado()) {
                System.out.println(habitacion);
            }
        }
    }

    public double obtenerPrecioPorIdentificador(String identificador) {
        for (Habitaciones habitacion : habitaciones) {
            if (habitacion != null && habitacion.getIdentificador().equals(identificador)) {
                return habitacion.getPrecio();
            }
        }
        return -1;
    }

    public void hacerReserva(String identificador) {
        for (Habitaciones habitacion : habitaciones) {
            if (habitacion != null && habitacion.getIdentificador().equals(identificador)) {
                if (!habitacion.getOcupado()) {
                    habitacion.setOcupado(true);
                    System.out.println("Reserva realizada para la habitación: " + identificador);
                    return;
                } else {
                    System.out.println("La habitación ya está ocupada. No se puede reservar.");
                    return;
                }
            }
        }
        System.out.println("No existe ninguna habitación con ese código.");
    }
    
    public void listarHabitacionesReservadas() {
        for (Habitaciones habitacion : habitaciones) {
            if (habitacion != null && habitacion.getOcupado()) {
                System.out.println(habitacion);
            }
        }
    }
}
