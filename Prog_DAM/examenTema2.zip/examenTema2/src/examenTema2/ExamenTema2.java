package examenTema2;

public class ExamenTema2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("esPrimo (17): " + Funciones.esPrimo(17));
		System.out.println("esPrimo (20): " + Funciones.esPrimo(20));
		System.out.println("siguientePrimo (17): " + Funciones.siguientePrimo(17));
		System.out.println("siguientePrimo (20): " + Funciones.siguientePrimo(20));
		System.out.println("digitos (1234): " + Funciones.digitos(1234));
		System.out.println("voltea (1234): " + Funciones.voltea(1234));
		System.out.println("quitarPorDetras (12345): " + Funciones.quitarPorDetras(12345));
		System.out.println("quitarPorDelante (12345): " + Funciones.quitaPorDelante(12345));
		System.out.println("pegarPorDetras (12345,9): " + Funciones.pegarPorDetras(12345, 9));
		System.out.println("pegarPorDelante (12345, 9): " + Funciones.pegarPorDelante(12345, 9));
	}

}
